#pragma once

extern float voltage, rsoc;
void getRSOC();