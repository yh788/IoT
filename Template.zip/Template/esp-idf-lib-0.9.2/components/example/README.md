# `example`

An example driver. Use this as an template for new driver.

## Usage

As this is an example, no usage is available.
