ENCODING: str = 'utf-8'

METADATA_FILENAME: str = '.eil.yml'
GROUPS_FILENAME: str = 'groups.yml'
PERSONS_FILENAME: str = 'persons.yml'
TARGETS_FILENAME: str = 'targets.yml'
DICT_DIR: str = 'devtools'
COMPONENTS_DIR: str = 'components'
