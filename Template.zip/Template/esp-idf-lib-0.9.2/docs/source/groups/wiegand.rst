.. _wiegand:

wiegand - Weigand protocol receiver for ESP-IDF
===============================================

.. doxygengroup:: wiegand
   :members:

