.. _sht4x:

sht4x - driver for Sensirion SHT40/SHT41 digital temperature and humidity sensors
=================================================================================

.. doxygengroup:: sht4x
   :members:

