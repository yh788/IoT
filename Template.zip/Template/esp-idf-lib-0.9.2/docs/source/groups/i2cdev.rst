.. _i2cdev:

i2cdev - I2C master thread-safe functions for communication with I2C slave
==========================================================================

.. doxygengroup:: i2cdev
   :members:
