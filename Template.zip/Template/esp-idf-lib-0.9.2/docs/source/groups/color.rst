.. _color:

color - Library for RGB and HSV colors
======================================

.. note:: This library was ported from FastLED

.. doxygengroup:: rgb
   :members:

.. doxygengroup:: hsv
   :members:

.. doxygengroup:: color
   :members:

