.. _ads111x:

ads111x - Driver for ADS1113/ADS1114/ADS1115 and ADS1013/ADS1014/ADS1015 I2C ADC
================================================================================

.. doxygengroup:: ads111x
   :members:

