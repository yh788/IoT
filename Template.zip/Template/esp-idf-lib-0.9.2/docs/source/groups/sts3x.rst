.. _sts3x:

sts3x - Driver for Sensirion STS3x digital temperature sensor
==========================================================================

.. doxygengroup:: sts3x
   :members:
